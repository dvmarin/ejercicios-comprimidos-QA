README – Ejercicio 1
Prueba E2E Funcional con Cypress.io

1. Descripción
Este ejercicio consiste en la automatización de un flujo de compra End-To-End
sobre la página web httpswww.demoblaze.com, utilizando Cypress.io como
framework de automatización.

El flujo automatizado incluye
- Selección de productos
- Adición de productos al carrito
- Visualización del carrito
- Completar formulario de compra
- Finalización de la compra

2. Requisitos previos
- Node.js versión LTS instalada
- NPM instalado (incluido con Node.js)
- Navegador Google Chrome
- Editor de código (utilizado en la practica Visual Studio Code)

3. Instalación del proyecto
Desde la raíz del proyecto ejecutar

npm install

Esto instalará todas las dependencias necesarias, incluyendo Cypress.

4. Ubicación del script
El script de automatización E2E se encuentra en la siguiente ruta

cypresse2ee2ecompra_e2e.cy.js

5. Ejecución de la prueba

Modo interactivo
npx cypress open

Luego
- Seleccionar E2E Testing
- Seleccionar navegador Chrome
- Ejecutar el archivo compra_e2e.cy.js

Modo headless
npx cypress run --spec cypresse2ee2ecompra_e2e.cy.js

6. Consideraciones
- Se utiliza una espera controlada para permitir la visualización del carrito.
- El flujo valida la correcta finalización de la compra mediante el mensaje
  de confirmación.
- El test está diseñado para ejecutarse de forma automática sin intervención manual.
