describe('Flujo de compra Demoblaze', () => {

  before(() => {
    cy.visit('https://www.demoblaze.com/');
  });

  it('Compra de dos productos', () => {

    //Agregar producto 1
    cy.contains('Samsung galaxy s6').click();
    cy.contains('Add to cart').click();
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Product added');
    });

    cy.contains('Home').click();

    //Agregar producto 2
    cy.contains('Sony vaio i5').click();
    cy.contains('Add to cart').click();
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Product added');
    });

    //Abrir el carrito
    cy.contains('Cart').click();
    cy.url().should('include', 'cart');
    cy.wait(2000); //Tiempo de espera para visualizar el carrito

    //Validar productos
    cy.get('tr.success').should('have.length.at.least', 2);

    //Realizar compra
    cy.contains('Place Order').click();

    //Formulario
    cy.get('#name').type('Valentina Marin');
    cy.get('#country').type('Colombia');
    cy.get('#city').type('Bogotá');
    cy.get('#card').type('4111111111111111');
    cy.get('#month').type('12');
    cy.get('#year').type('2025');

    cy.contains('Purchase').click();

    //Confirmación
    cy.contains('Thank you for your purchase').should('be.visible');
    cy.wait(2000); //Tiempo de espera para visualizar la alerta de confirmacion
    cy.contains('OK').click();
  });
});
