README – Ejercicio 2
Pruebas de API con Cypress.io

1. Descripción
Este ejercicio consiste en la automatización de pruebas sobre los servicios
REST de registro (Signup) y autenticación (Login) proporcionados por la
plataforma https://www.demoblaze.com/.

Los endpoints probados son:
- Signup: https://api.demoblaze.com/signup
- Login: https://api.demoblaze.com/login

2. Casos de prueba cubiertos
- Crear un nuevo usuario en el servicio Signup
- Intentar crear un usuario ya existente
- Login con usuario y contraseña correctos
- Login con usuario y/o contraseña incorrectos

3. Requisitos previos
- Node.js versión LTS
- NPM
- Cypress instalado como dependencia del proyecto

4. Ubicación del script
El script de pruebas de API se encuentra en la siguiente ruta:

cypress/e2e/api/apis_demoblaze.cy.js

5. Ejecución de las pruebas

Modo interactivo:
npx cypress open

Luego:
- Seleccionar "E2E Testing"
- Ejecutar el archivo apis_demoblaze.cy.js

Modo headless:
npx cypress run --spec cypress/e2e/api/apis_demoblaze.cy.js

6. Consideraciones técnicas
- Los servicios solo aceptan peticiones HTTP POST.
- Se genera un usuario dinámico para evitar conflictos por duplicidad.
- Se validan tanto respuestas exitosas como mensajes de error del servicio.
