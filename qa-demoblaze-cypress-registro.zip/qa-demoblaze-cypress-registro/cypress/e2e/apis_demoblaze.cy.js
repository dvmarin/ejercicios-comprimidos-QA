describe('Pruebas de API Demoblaze - Signup y Login', () => {

  // Usuario dinámico 
  const username = `user_${Date.now()}`;
  const password = '123456';

  it('Crear un nuevo usuario (signup)', () => {
    cy.request({
      method: 'POST',
      url: 'https://api.demoblaze.com/signup',
      body: { username, password }
    }).then((response) => {
      expect(response.status).to.eq(200);

      if (typeof response.body === 'string' && response.body !== '') {
        const parsed = JSON.parse(response.body);
        expect(parsed).to.have.property(
          'errorMessage',
          'This user already exist.'
        );
      } else {
        expect(response.body).to.eq('');
      }
    });

  });

  it('Intentar crear un usuario ya existente', () => {
    cy.request({
      method: 'POST',
      url: 'https://api.demoblaze.com/signup',
      failOnStatusCode: false,
      body: {
        username: username,
        password: password
      }
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.errorMessage).to.contain('This user already exist');
    });
  });

  it('Login con usuario y password correctos', () => {
    cy.request({
      method: 'POST',
      url: 'https://api.demoblaze.com/login',
      body: {
        username: username,
        password: password
      }
    }).then((response) => {
      expect(response.status).to.eq(200);

      // Login exitoso
      if (response.body !== '') {
        expect(response.body).to.include('Auth_token');
      } else {
        expect(response.body).to.eq('');
      }
    });
  });

  it('Login con usuario o password incorrectos', () => {
    cy.request({
      method: 'POST',
      url: 'https://api.demoblaze.com/login',
      failOnStatusCode: false,
      body: {
        username: username,
        password: 'password_incorrecto'
      }
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.errorMessage).to.contain('Wrong password');
    });
  });

});
